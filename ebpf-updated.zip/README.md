# Terraform Setup for LAB ECE6383

## Register Linode Account

## Obtain API Token
![Step1](assets/step1.png)
![Step2](assets/step2.png)
![Step3](assets/step3.png)
## Obtain Copy of Terraform Code
_Command:_
```
git clone https://xxxxxxxxxxx
cd xxxxxxxxx/lab6383
```

## Install and Setup Terraform
https://developer.hashicorp.com/terraform/tutorials/aws-get-started/install-cli

## Run Terraform
> **Warning**
> All Terraform commands should be executed in the same directory as main.tf for this project.
### Init
_Command:_
```
terraform init
```
_Success Result:_
```
Terraform has been successfully initialized!

You may now begin working with Terraform. Try running "terraform plan" to see
any changes that are required for your infrastructure. All Terraform commands
should now work.

If you ever set or change modules or backend configuration for Terraform,
rerun this command to reinitialize your working directory. If you forget, other
commands will detect it and remind you to do so if necessary.
```
### Apply
_Command:_
```
terraform apply
```
_Success Result:_
```
null_resource.configure_reflector: Still creating... [1m50s elapsed]
null_resource.configure_reflector: Still creating... [2m0s elapsed]
null_resource.configure_reflector: Creation complete after 2m6s [id=399982574051471313]

Apply complete! Resources: 4 added, 0 changed, 0 destroyed
```

### Destroy
_Command:_
```
terraform destroy
```
_Success Result:_
```
linode_instance.receiver_instance: Destruction complete after 37s
linode_instance.sender_instance: Still destroying... [id=49772385, 40s elapsed]
linode_instance.sender_instance: Destruction complete after 48s

Apply complete! Resources: 0 added, 0 changed, 4 destroyed.
```

### eBPF verification
1. login to sender
2. attach tmux session by running
```
tmux at -t client 
```
3. type in message and enter, ex "asdf"
4. login to server
5. attach tmux session by running
```
tmux at -t server 
```
6. first letter being modified to _