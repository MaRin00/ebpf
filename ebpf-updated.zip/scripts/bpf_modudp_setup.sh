#!/bin/bash
# https://taoshu.in/unix/modify-udp-packet-using-ebpf.html

sudo apt -q update && sudo apt install build-essential linux-headers-$(uname -r) llvm clang -y

clang -O2 -target bpf -I /usr/include/x86_64-linux-gnu -c /tmp/src/bpf.c -o bpf.o

interface_name=$(ip -o -4 route show default | awk '{print $5}')
tc qdisc add dev ${interface_name} clsact
tc filter add dev ${interface_name} ingress bpf da obj bpf.o sec modudp
tc filter add dev ${interface_name} egress bpf da obj bpf.o sec modudp
